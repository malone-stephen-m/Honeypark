#
# Ari Kapusta and Adam Cantor
# CS 6601
# 10/16/2013
# 
# Project 1
#
# README to run the code
#
#
#
#
# To run the code:
#
# Unpack zip file. The code is in java. Execute the program (I just hit execute in Eclipse, I think it is executing AntsApplet.java).
# Click scenarios 1 - 4. It will load the scenario and begin running the test. Press play to pause and continue the test. Press step to
# make the program step forward one time-step.
#
# Questions: call, email, contact Ari and Adam.
#
#
