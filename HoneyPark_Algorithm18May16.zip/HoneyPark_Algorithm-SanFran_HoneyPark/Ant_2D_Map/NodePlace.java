
public class NodePlace {
	private int locx;
	private int locy;
	public NodePlace(int x, int y) {
		this.locx = x;
		this.locy = y;
	}
	
	public int getX() {
		return locx;
	}

	public int getY() {
		return locy;
	}
}
